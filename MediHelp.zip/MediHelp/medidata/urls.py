from medidata.views import home,HospitalDetailView,developer
from django.contrib import admin
from django.urls import path

urlpatterns = [

    path('',home,name='homepage'),
    path('developer/',developer,name='developer'),
    path('hospital/<int:pk>/',HospitalDetailView.as_view(),name='hospital_detail'),
]